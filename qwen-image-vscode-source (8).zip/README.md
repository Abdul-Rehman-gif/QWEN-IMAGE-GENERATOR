# Qwen-Image Local Runner (VS Code Extension)

Automates running the Qwen-Image open-source image generation model locally via ComfyUI —
no manual terminal commands needed after the initial setup.

## What this does

1. **Checks your system** — Python, Git, NVIDIA GPU/VRAM.
2. **Installs ComfyUI** — clones the repo and installs its Python dependencies.
3. **Downloads model files** — GGUF checkpoint, text encoder, mmproj, VAE from Hugging Face,
   sized to your chosen quantization level.
4. **Launches the server** — starts ComfyUI as a background process.
5. **Generates images** — type a prompt in VS Code, get the image back automatically,
   no need to touch the ComfyUI node graph UI.

## Requirements before you start

- **Python 3.10 or 3.11** installed and on PATH
- **Git** installed and on PATH
- (Recommended) **NVIDIA GPU** with 8GB+ VRAM and up-to-date drivers.
  CPU-only works but is much slower.
- A few GB to ~15GB of free disk space depending on the quant you choose.

## How to install this extension

Since this isn't published to the Marketplace, install it from the `.vsix` file:

```bash
code --install-extension qwen-image-local-0.1.0.vsix
```

Or in VS Code: open the Command Palette → "Extensions: Install from VSIX..." → select the file.

## How to use it

Open the Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) and run, in order:

1. **`Qwen-Image: Check System Requirements`** — confirms Python/Git/GPU are ready.
2. **`Qwen-Image: Run Full Setup (Install + Download + Launch)`** — does steps 2-4 above
   in one go. Grab a coffee; downloading models takes a while depending on your connection.
3. **`Qwen-Image: Generate Image`** — type a prompt, wait for generation, the result opens
   automatically. You can run this command repeatedly for new prompts.

Individual steps (`1. Install ComfyUI`, `2. Download Model Files`, `3. Start Server`,
`Stop Server`) are also available separately if you want more control or need to re-run
just one stage.

## Settings

Open Settings (`Ctrl+,`) and search "Qwen Image" to configure:

- `qwenImage.quantVariant` — `Q2_K` / `Q3_K_S` (8GB VRAM) up to `Q4_K_M`/`Q5_K_M`/`FP8`
  (12GB+/16GB+ VRAM). Lower = smaller and faster, but lower image quality.
- `qwenImage.installDir` — where ComfyUI gets installed (defaults to
  `~/qwen-image-local/ComfyUI`).
- `qwenImage.pythonPath` — change if `python` isn't the right command on your system
  (e.g. `python3`).
- `qwenImage.hfRepoGGUF` / `hfRepoTextEncoder` / `hfRepoVAE` — Hugging Face repo IDs the
  downloader pulls from. Model maintainers sometimes rename or move files — if a download
  fails, check Hugging Face for the current repo/filename and update these settings
  (or download the file manually into the matching `ComfyUI/models/...` folder).

## Notes and known limitations

- **Model file locations change.** Open-source model hosting moves fast; the default
  Hugging Face repo IDs baked into this extension may need updating over time. If a
  download 404s, that's almost always why — check `resources/workflow_api.json` and the
  settings above.
- **The bundled workflow is a starting template.** It targets the standard
  [ComfyUI-GGUF](https://github.com/city96/ComfyUI-GGUF) custom node loaders
  (`UnetLoaderGGUF`, `CLIPLoaderGGUF`). If you see a "node not found" style error when
  generating, install the ComfyUI-GGUF custom node pack into
  `ComfyUI/custom_nodes/` (via ComfyUI Manager or `git clone` it in that folder) and
  restart the server.
- First generation after starting the server is slower (model loads into VRAM/RAM).
  Subsequent generations in the same session are faster.
- To fully uninstall, just delete the `qwenImage.installDir` folder — this extension
  never touches anything outside it.
